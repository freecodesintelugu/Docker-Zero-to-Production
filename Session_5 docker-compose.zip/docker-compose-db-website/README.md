# Docker Compose: Flask + MySQL Student Directory

A beginner-friendly class demo showing a website connected to a database using Docker Compose.

## Architecture

Browser -> Flask web service -> MySQL database

- `web`: Flask website, built from `Dockerfile`, exposed at host port `5000`.
- `db`: MySQL 8.4 database; accessible to the web service by DNS name `db` on internal port `3306`.
- `mysql-data`: named volume for persistent database files.
- `db/init.sql`: creates the `students` table and inserts one sample row on the first database initialization.

## Prerequisites

Install Docker Desktop (Windows/macOS) or Docker Engine plus the Compose plugin (Linux). Ensure Docker is running.

Check:

```bash
docker --version
docker compose version
```

## Run the project

1. Extract the ZIP.
2. Open a terminal in the extracted `docker-compose-db-website` folder (the folder containing `compose.yaml`).
3. Start the project:

```bash
docker compose config
docker compose up -d --build
docker compose ps
```

The first run downloads the base images and may take a few minutes. The database health check delays web startup until MySQL is ready.

4. Open in your browser:

- Website: http://localhost:5000
- Health endpoint: http://localhost:5000/health

5. Add a student and refresh the page. The row should remain in MySQL.

## Useful commands

```bash
# Follow logs
docker compose logs -f

# Show only web or database logs
docker compose logs -f web
docker compose logs -f db

# Open a shell in the web container
docker compose exec web sh

# Open MySQL CLI inside the database container
docker compose exec db mysql -udemo_user -pdemo_password_change_me classdemo

# Inside MySQL, try:
# SHOW TABLES;
# SELECT * FROM students;

# Restart services
docker compose restart

# Stop and remove containers and Compose network (keeps named volume)
docker compose down

# Start again
docker compose up -d

# WARNING: deletes the project's named volume and database records
docker compose down -v
```

## Teach these concepts

- `services`: components of the application.
- `build: .`: build the web image from the local Dockerfile.
- `image`: use a published image (MySQL).
- `ports`: host-to-container port mapping; only the web port is published.
- `environment`: configure the web-to-database connection.
- `depends_on` with `condition: service_healthy`: wait for MySQL health check before starting the web service.
- `volumes`: persist MySQL database files across container recreation.
- Compose DNS: the web container connects to host `db`, not `localhost`.
- Parameterized SQL query: inserts form values safely rather than concatenating user input into SQL.

## Troubleshooting

### Website does not open

```bash
docker compose ps
docker compose logs web
docker compose logs db
```

Check Docker is running and port `5000` is not already in use.

### Database is still starting

```bash
docker compose ps
docker compose logs -f db
```

Wait until the database health status is healthy, then reload the website.

### Changed the code

```bash
docker compose up -d --build
```

### Reset demo data

Only if you are happy to delete the demo database volume:

```bash
docker compose down -v
docker compose up -d --build
```

The initialization SQL runs only when MySQL initializes an empty data directory. Editing `db/init.sql` will not rerun it against an existing volume.

## Classroom security note

The credentials in `compose.yaml` are deliberately simple demo credentials. Do not use them in production. For real deployments, use secret management, least-privilege accounts, backups, TLS where appropriate, patched images, and avoid exposing the database port publicly.

This sample is for teaching and local development, not a hardened production deployment.
