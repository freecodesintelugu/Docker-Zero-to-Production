import os
import time
from contextlib import closing

import mysql.connector
from mysql.connector import Error
from flask import Flask, request, redirect, url_for, render_template_string

app = Flask(__name__)

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "db"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "database": os.getenv("DB_NAME", "classdemo"),
    "user": os.getenv("DB_USER", "demo_user"),
    "password": os.getenv("DB_PASSWORD", "demo_password_change_me"),
}

PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Compose Student Directory</title>
  <style>
    :root { color-scheme: light; --ink:#182235; --blue:#1463df; --bg:#f3f6fb; }
    * { box-sizing: border-box; }
    body { margin:0; font-family:system-ui,Segoe UI,Arial,sans-serif; background:var(--bg); color:var(--ink); }
    header { background:#101a2d; color:white; padding:26px 20px; }
    header div, main { max-width:900px; margin:auto; }
    header p { color:#c5d5f2; margin-bottom:0; }
    main { padding:24px 16px 48px; }
    .status { padding:12px 15px; border-radius:10px; background:#e0f7e9; color:#14532d; margin-bottom:18px; }
    .card { background:white; border:1px solid #e1e7f0; border-radius:14px; padding:20px; margin-bottom:18px; box-shadow:0 4px 18px #15213a0a; }
    form { display:grid; grid-template-columns:1fr 1fr auto; gap:10px; }
    input, button { font:inherit; padding:11px 12px; border-radius:8px; border:1px solid #cbd5e1; }
    button { background:var(--blue); color:white; border:0; cursor:pointer; font-weight:650; }
    table { width:100%; border-collapse:collapse; }
    th, td { text-align:left; padding:12px 8px; border-bottom:1px solid #e8edf4; }
    th { color:#526078; font-size:.9rem; }
    .muted { color:#64748b; font-size:.92rem; }
    .error { background:#fee2e2; color:#991b1b; padding:12px; border-radius:8px; }
    @media(max-width:620px) { form { grid-template-columns:1fr; } .card { padding:15px; } }
  </style>
</head>
<body>
<header><div>
  <h1>Student Directory</h1>
  <p>Docker Compose · Flask + MySQL · FreeCodes In Telugu</p>
</div></header>
<main>
  {% if db_error %}
    <div class="error"><strong>Database connection error.</strong> Check service status and logs with <code>docker compose ps</code> and <code>docker compose logs db web</code>.</div>
  {% else %}
    <div class="status">✓ Connected to MySQL database <strong>{{ db_name }}</strong></div>
  {% endif %}
  <section class="card">
    <h2>Add a student</h2>
    <p class="muted">This form sends data from Flask to MySQL using a parameterized query.</p>
    <form method="post" action="{{ url_for('add_student') }}">
      <input name="name" placeholder="Student name" maxlength="100" required>
      <input name="course" placeholder="Course (e.g. Docker)" maxlength="100" required>
      <button type="submit" {% if db_error %}disabled{% endif %}>Save student</button>
    </form>
  </section>
  <section class="card">
    <h2>Saved students</h2>
    {% if db_error %}
      <p>Records cannot be loaded until the database is available.</p>
    {% elif students %}
      <table><thead><tr><th>ID</th><th>Name</th><th>Course</th></tr></thead><tbody>
      {% for student in students %}
        <tr><td>{{ student[0] }}</td><td>{{ student[1] }}</td><td>{{ student[2] }}</td></tr>
      {% endfor %}
      </tbody></table>
    {% else %}
      <p>No students yet. Add one using the form above.</p>
    {% endif %}
  </section>
  <p class="muted">Teaching demo only. Use proper secrets and production hardening before deployment.</p>
</main>
</body>
</html>
"""

def get_connection():
    return mysql.connector.connect(**DB_CONFIG, connection_timeout=3)

def fetch_students():
    with closing(get_connection()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute("SELECT id, name, course FROM students ORDER BY id DESC")
            return cur.fetchall()

@app.route("/", methods=["GET"])
def home():
    db_error = False
    students = []
    try:
        students = fetch_students()
    except Error:
        db_error = True
    return render_template_string(
        PAGE, students=students, db_error=db_error, db_name=DB_CONFIG["database"]
    ), (503 if db_error else 200)

@app.route("/students", methods=["POST"])
def add_student():
    name = request.form.get("name", "").strip()
    course = request.form.get("course", "").strip()
    if not name or not course:
        return "Name and course are required.", 400
    try:
        with closing(get_connection()) as conn:
            with closing(conn.cursor()) as cur:
                # Parameterized query helps prevent SQL injection.
                cur.execute(
                    "INSERT INTO students (name, course) VALUES (%s, %s)",
                    (name, course),
                )
            conn.commit()
    except Error:
        return "Could not save the student. Check application/database logs.", 503
    return redirect(url_for("home"))

@app.route("/health", methods=["GET"])
def health():
    try:
        with closing(get_connection()) as conn:
            with closing(conn.cursor()) as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return {"status": "healthy", "database": "connected"}
    except Error:
        return {"status": "unhealthy", "database": "disconnected"}, 503

if __name__ == "__main__":
    # Retry briefly while the database finishes initialization.
    for attempt in range(15):
        try:
            with closing(get_connection()) as conn:
                with closing(conn.cursor()) as cur:
                    cur.execute("SELECT 1")
            break
        except Error:
            if attempt == 14:
                print("Database is not ready; app will still serve health/error page.")
            else:
                time.sleep(2)
    app.run(host="0.0.0.0", port=5000)
