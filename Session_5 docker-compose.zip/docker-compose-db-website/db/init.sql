CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO students (name, course)
SELECT 'Demo Student', 'Docker Compose'
WHERE NOT EXISTS (
    SELECT 1 FROM students WHERE name = 'Demo Student' AND course = 'Docker Compose'
);
