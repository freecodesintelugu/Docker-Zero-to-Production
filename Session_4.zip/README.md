# Docker Session 4: Dockerfile Tutorial — Build Your Own Docker Image

**Channel:** FreeCodes In Telugu  
**Series:** Docker Zero to Production | **Session:** 04  
**Level:** Beginner to Intermediate

## English Explanation

### What is a Dockerfile?
A Dockerfile is a text file containing instructions Docker uses to build an image. It defines the base image, files to copy, dependencies to install, runtime configuration, and default startup command.

Think of it as a recipe:
- Source code is the input.
- The Dockerfile describes how to package it.
- The image is the built template.
- A container is a running instance of that image.

### What we will build
A small Python Flask website. We will package it into a custom Docker image, run it in a container, and open it in a browser.

### Dockerfile instructions covered

| Instruction | Purpose |
|---|---|
| `FROM` | Selects the base image |
| `LABEL` | Adds image metadata |
| `ARG` | Defines a build-time variable |
| `WORKDIR` | Sets the working directory |
| `COPY` | Copies files from build context into the image |
| `RUN` | Executes commands during image build |
| `ENV` | Sets environment variables available at runtime |
| `USER` | Sets the user for later build steps and default runtime process |
| `EXPOSE` | Documents a container port; it does not publish the port |
| `HEALTHCHECK` | Defines a health probe |
| `CMD` | Sets the default startup command or arguments |
| `.dockerignore` | Excludes files from the build context |

We also demonstrate `ENTRYPOINT` and `VOLUME` separately.

### Project structure

```text
Docker_Session_4_GitHub_Repo/
├── app.py
├── requirements.txt
├── Dockerfile
├── Dockerfile.entrypoint
├── .dockerignore
└── templates/
    └── index.html
```

### Requirements
- Docker Desktop (Windows/macOS) or Docker Engine (Linux)
- Docker daemon running
- Terminal (PowerShell, Windows Terminal, or Bash)
- Internet access for the first image build

Check Docker:

```bash
docker --version
docker info
```

### Build your image

Run from the repository root:

```bash
docker build -t python-docker-lab:v1 .
```

- `docker build`: builds an image.
- `-t`: assigns an image name and tag.
- `python-docker-lab:v1`: image name and version.
- `.`: current directory is the build context, subject to `.dockerignore`.

Inspect the image:

```bash
docker images
docker image inspect python-docker-lab:v1
docker image inspect --format='{{json .Config.Labels}}' python-docker-lab:v1
```

### Run the container

```bash
docker run -d --name python-docker-lab -p 8080:5000 python-docker-lab:v1
```

Open **http://localhost:8080**

- `-d`: run in background.
- `--name`: assign a readable container name.
- `-p 8080:5000`: map host port 8080 to container port 5000.

### Verify the app

```bash
docker ps
docker logs python-docker-lab
docker inspect --format='{{.State.Health.Status}}' python-docker-lab
curl http://localhost:8080/health
```

Expected health endpoint response:

```json
{"status":"healthy"}
```

The health status may take a short time to appear while Docker performs its first checks.

### Demonstrate ENV

The website reads `APP_ENV` and `APP_VERSION` from environment variables. Run a second container with different values:

```bash
docker run -d --name python-docker-staging -p 8081:5000 -e APP_ENV=staging -e APP_VERSION=2.0 python-docker-lab:v1
```

Open **http://localhost:8081**. It should show `staging` and version `2.0`.

```bash
docker exec python-docker-staging printenv APP_ENV
docker exec python-docker-staging printenv APP_VERSION
```

`ARG` is for build-time configuration; `ENV` sets defaults available at runtime. Never store passwords or tokens in a Dockerfile or image layers.

### CMD vs ENTRYPOINT

`CMD` provides a default command or arguments. `ENTRYPOINT` defines the main executable. With exec-form `ENTRYPOINT`, arguments passed to `docker run` normally replace default `CMD` arguments.

`Dockerfile.entrypoint`:

```dockerfile
FROM alpine:3.22
ENTRYPOINT ["echo"]
CMD ["Hello Docker"]
```

Build and run:

```bash
docker build -f Dockerfile.entrypoint -t entrypoint-demo .
docker run --rm entrypoint-demo
docker run --rm entrypoint-demo "Hello Telugu"
```

Expected outputs: `Hello Docker`, then `Hello Telugu`.

### Demonstrate VOLUME

The Flask website does not require persistent storage, so volume use is shown separately:

```bash
docker volume create demo-data
docker run --rm -v demo-data:/data alpine:3.22 sh -c 'echo hello > /data/message.txt'
docker run --rm -v demo-data:/data alpine:3.22 cat /data/message.txt
docker volume rm demo-data
```

Expected output: `hello`. A volume helps preserve data outside a container's writable layer, but it is not a backup.

### Update the application

After changing the app or template, build a new image:

```bash
docker build -t python-docker-lab:v2 .
```

A running container does not automatically switch to a new image. Recreate it:

```bash
docker rm -f python-docker-lab
docker run -d --name python-docker-lab -p 8080:5000 python-docker-lab:v2
```

Refresh **http://localhost:8080**.

### Troubleshooting

| Problem | What to check |
|---|---|
| Docker daemon unavailable | Start Docker Desktop or Docker service |
| Dockerfile not found | Build from repository root; check exact filename |
| `COPY` fails | Check paths and `.dockerignore` |
| Port already allocated | Try another host port, e.g. `8082:5000` |
| Container name exists | Remove or rename the old container |
| Website unavailable | Check `docker ps`, logs, and port mapping |
| Health status is `starting` | Wait for initial checks and inspect logs |
| Updated code not visible | Rebuild image and recreate container |

### Cleanup

```bash
docker rm -f python-docker-lab
docker rm -f python-docker-staging
docker image rm python-docker-lab:v1 python-docker-lab:v2
```

Only remove resources created for this lab. If you did not create a container or image tag, its cleanup command may report that it does not exist.

---

## Telegish Explanation (Telugu + English)

### Dockerfile ante enti?
Dockerfile anedi oka text file. Docker image build cheyadaniki kavalsina instructions anni indulo rastam.

Intlo cooking cheyadaniki recipe follow avutham kada? Ye ingredients kavali, ela prepare cheyyali ani recipe chepthundi. Alage Dockerfile, application ni Docker image ga ela package cheyyalo Docker ki chepthundi.

- Application code mana input.
- Dockerfile build instructions.
- Docker image ready-made template.
- Container anedi image nunchi run ayye instance.

### Ee session lo em build chestham?
Manam Python Flask tho oka small website create chestham. Tarvata Dockerfile rayi, custom image build chesi, container run chesi browser lo website open chestham.

### Dockerfile instructions easy ga
- `FROM`: base image select chestundi.
- `LABEL`: image ki metadata add chestundi.
- `ARG`: build time lo use chese variable.
- `WORKDIR`: container lopala working directory set chestundi.
- `COPY`: project files ni image lopaliki copy chestundi.
- `RUN`: image build avuthunnappudu command execute chestundi.
- `ENV`: runtime environment variables set chestundi.
- `USER`: application ni ye user tho run cheyyalo set chestundi.
- `EXPOSE`: container port ni document chestundi; host port automatic ga publish cheyyadu.
- `HEALTHCHECK`: application response istunda ani check cheyadaniki command define chestundi.
- `CMD`: container start ayinappudu default command or arguments set chestundi.
- `.dockerignore`: build context lo avasaram leni files ni exclude chestundi.

### Image build cheyyadam

```bash
docker build -t python-docker-lab:v1 .
```

`-t` image ki name and tag istundi. `v1` version. Last lo dot (`.`) current directory ni build context ga use cheyyamani chepthundi.

### Container run cheyyadam

```bash
docker run -d --name python-docker-lab -p 8080:5000 python-docker-lab:v1
```

- `-d`: background lo run chestundi.
- `--name`: container ki name istundi.
- `-p 8080:5000`: host port `8080` ni container port `5000` ki map chestundi.

Browser lo **http://localhost:8080** open cheyyandi.

### ENV practical

```bash
docker run -d --name python-docker-staging -p 8081:5000 -e APP_ENV=staging -e APP_VERSION=2.0 python-docker-lab:v1
```

**http://localhost:8081** open chesthe `staging`, version `2.0` ani kanipinchali. Same image ni different environment variables tho run cheyochu.

### CMD vs ENTRYPOINT
`CMD` default command or arguments ni set chestundi. `ENTRYPOINT` main executable ni define chestundi. Example run chesthe `Hello Docker` print avutundi; vere argument pass chesthe `Hello Telugu` print avutundi.

### Health check
```bash
docker inspect --format='{{.State.Health.Status}}' python-docker-lab
curl http://localhost:8080/health
```

Health status first time ravadaniki konchem time pattachu. Container running lo undadam, application healthy ga undadam rendu different concepts.

### Code update chesinappudu
Code update chesaka new image build cheyyali:

```bash
docker build -t python-docker-lab:v2 .
```

Existing container automatic ga new image use cheyyadu. Container ni recreate cheyyali:

```bash
docker rm -f python-docker-lab
docker run -d --name python-docker-lab -p 8080:5000 python-docker-lab:v2
```

### Final recap
Ee session lo Dockerfile instructions, image build, container run, port mapping, environment variables, health checks, `CMD` vs `ENTRYPOINT`, and image version updates practice chestham.

---

## Practice Tasks

1. Change the heading in `templates/index.html`, rebuild as `v2`, and recreate the container.
2. Run the same image with `APP_ENV=development` and `APP_ENV=production`.
3. Change the host port to `8082`.
4. Inspect image labels using `docker image inspect`.
5. Check container health status.
6. Run the `ENTRYPOINT` demo and explain why the output changes.
7. Complete the volume demo and explain why the file is available in the second container.

## Important Notes

- Run commands from the repository root unless otherwise specified.
- Keep secrets out of the Dockerfile and image.
- `EXPOSE` documents a port; `-p` publishes it.
- Building a new image does not update an already-running container.
- Review production requirements before public deployment.

**Author / Channel:** FreeCodes In Telugu  
**Topic:** Dockerfile, Docker Image, Python Flask, DevOps
