import os
from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return render_template(
        "index.html",
        app_env=os.getenv("APP_ENV", "not-set"),
        app_version=os.getenv("APP_VERSION", "1.0"),
    )

@app.route("/health")
def health():
    return {"status": "healthy"}, 200

if __name__ == "__main__":
    # Bind to all container interfaces so Docker port publishing can reach Flask.
    app.run(host="0.0.0.0", port=5000)
