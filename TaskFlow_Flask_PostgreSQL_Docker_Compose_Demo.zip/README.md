# TaskFlow — Docker Compose Database Demo

A small, polished task manager built with Flask and PostgreSQL. It demonstrates a web container connecting to a separate database container through Docker Compose.

## Features
- Create tasks with category and priority
- Mark tasks complete or pending
- Delete tasks
- Dashboard totals for all, pending and completed tasks
- PostgreSQL named volume for persistent data
- Database health check and `/health` endpoint

## Run locally or on EC2

```bash
docker compose up -d --build
docker compose ps
docker compose logs --tail=50
```

Open `http://YOUR_EC2_PUBLIC_IP:5000`. Restrict inbound TCP port 5000 to your own IP in the EC2 security group for a learning demo.

## Explain in your Docker Compose session
- `web` and `db` are separate services/containers.
- `depends_on` with `service_healthy` waits for PostgreSQL to become ready.
- `DB_HOST: db` uses Compose DNS/service discovery; do not use `localhost` from the Flask container.
- `postgres_data` is a named volume so database records survive container recreation.
- The database port is not published to the host; only Flask port 5000 is published.

## Useful commands

```bash
docker compose ps
docker compose logs -f web
docker compose logs -f db
docker compose exec db psql -U taskuser -d taskdb
docker compose down
```

`docker compose down` preserves the named database volume. To delete the database data too, use `docker compose down -v` (destructive).
