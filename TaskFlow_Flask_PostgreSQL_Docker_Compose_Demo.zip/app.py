import os
import time
import psycopg2
from psycopg2.extras import RealDictCursor
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "compose-demo-change-me")

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "db"),
    "port": int(os.getenv("DB_PORT", "5432")),
    "dbname": os.getenv("POSTGRES_DB", "taskdb"),
    "user": os.getenv("POSTGRES_USER", "taskuser"),
    "password": os.getenv("POSTGRES_PASSWORD", "taskpass"),
}

def connect_db():
    last_error = None
    for _ in range(15):
        try:
            return psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
        except psycopg2.OperationalError as exc:
            last_error = exc
            time.sleep(2)
    raise last_error

def init_db():
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id SERIAL PRIMARY KEY,
                    title VARCHAR(180) NOT NULL,
                    category VARCHAR(40) NOT NULL DEFAULT 'General',
                    priority VARCHAR(10) NOT NULL DEFAULT 'Medium',
                    is_done BOOLEAN NOT NULL DEFAULT FALSE,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cur.execute("SELECT COUNT(*) AS count FROM tasks")
            if cur.fetchone()["count"] == 0:
                cur.executemany(
                    "INSERT INTO tasks (title, category, priority) VALUES (%s, %s, %s)",
                    [
                        ("Learn Docker Compose basics", "Learning", "High"),
                        ("Connect Flask to PostgreSQL", "Project", "High"),
                        ("Write a clean README", "Documentation", "Medium"),
                    ],
                )

@app.route("/")
def index():
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT id, title, category, priority, is_done,
                       TO_CHAR(created_at, 'Mon DD, YYYY') AS created_label
                FROM tasks ORDER BY is_done ASC, created_at DESC, id DESC
            """)
            tasks = cur.fetchall()
            cur.execute("""
                SELECT COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE is_done = TRUE) AS completed,
                       COUNT(*) FILTER (WHERE is_done = FALSE) AS pending
                FROM tasks
            """)
            stats = cur.fetchone()
    return render_template("index.html", tasks=tasks, stats=stats)

@app.post("/tasks")
def add_task():
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "General").strip() or "General"
    priority = request.form.get("priority", "Medium")
    if not title:
        flash("Please enter a task name.", "error")
        return redirect(url_for("index"))
    if priority not in ("Low", "Medium", "High"):
        priority = "Medium"
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO tasks (title, category, priority) VALUES (%s, %s, %s)",
                (title[:180], category[:40], priority),
            )
    flash("Task added successfully.", "success")
    return redirect(url_for("index"))

@app.post("/tasks/<int:task_id>/toggle")
def toggle_task(task_id):
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute("UPDATE tasks SET is_done = NOT is_done WHERE id = %s", (task_id,))
    return redirect(url_for("index"))

@app.post("/tasks/<int:task_id>/delete")
def delete_task(task_id):
    with connect_db() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
    flash("Task deleted.", "success")
    return redirect(url_for("index"))

@app.get("/health")
def health():
    try:
        with connect_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 AS ok")
                cur.fetchone()
        return {"status": "healthy", "database": "connected"}, 200
    except Exception:
        return {"status": "degraded", "database": "unavailable"}, 503

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
