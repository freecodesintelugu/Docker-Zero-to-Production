# Docker Compose — Session 5 | FreeCodes In Telugu

Learn Docker Compose by running a Flask web application and Redis cache together.

- **Level:** Beginner
- **Example:** Flask website + Redis page-visit counter
- **Tools:** Docker, Docker Compose, Python, Flask, Redis
- **Learning goals:** Compose services, images, containers, ports, networking, health checks, named volumes, logs, and cleanup

---

# Part 1 — English Explanation

## 1. What is Docker Compose?

**Docker Compose is a tool for defining and running multi-container Docker applications using a YAML configuration file.**

Instead of manually running and configuring each container, we describe the application's services in `compose.yaml` and manage them together.

For example, this lab contains:
- `web`: a Flask web application built from our Dockerfile.
- `redis`: a Redis service that stores the page-visit counter.

## 2. Important concepts

| Concept | Definition |
|---|---|
| Service | A component defined in the Compose file, such as `web` or `redis`. |
| Container | A running instance created from an image. |
| Image | A template used to create containers. |
| Port mapping | Connects a host port to a container port, for example `5000:5000`. |
| Network | Allows services in the Compose project to communicate. Compose services can use service names as hostnames. |
| Volume | Stores data outside a container's writable layer so it can survive container replacement. |
| Health check | A command used to check whether a service is responding as expected. |

## 3. Project architecture

```text
Browser
  |
  | http://localhost:5000
  v
Flask web service (container: web)
  |
  | Redis hostname: redis
  | Redis port: 6379
  v
Redis service (container: redis)
  |
  v
Named volume: redis-data
```

**Important:** Inside the `web` container, `localhost` refers to the web container itself. To connect to Redis, the app uses `redis:6379`, because `redis` is the Compose service name.

## 4. Project files

```text
docker-compose-session-5/
├── compose.yaml
├── Dockerfile
├── requirements.txt
├── app.py
├── .dockerignore
└── README.md
```

- `compose.yaml`: defines the services, port mapping, health check, and volume.
- `Dockerfile`: defines how to build the Flask application image.
- `requirements.txt`: lists Python packages.
- `app.py`: contains the website and Redis counter.
- `.dockerignore`: excludes unnecessary files from the image build context.
- `README.md`: instructions and learning notes.

## 5. Requirements

Install and start Docker Desktop on Windows/macOS, or install Docker Engine and the Docker Compose plugin on Linux.

Verify the installation:

```bash
docker --version
docker compose version
docker info
```

If `docker compose version` works, the Compose plugin is available. The `compose.yaml` file itself does not need to be installed.

## 6. Run the lab

Open a terminal in this project directory.

### Step 1 — Validate the Compose file

```bash
docker compose config
```

This prints the resolved configuration and helps catch YAML/configuration mistakes.

### Step 2 — Build and start the services

```bash
docker compose up -d --build
```

- `up`: creates and starts services.
- `-d`: runs them in the background.
- `--build`: builds the web image before starting.

On the first run, Docker may need to download the Python base image and Redis image, so internet access is required.

### Step 3 — Check status

```bash
docker compose ps
```

### Step 4 — View logs

```bash
docker compose logs -f
```

Press `Ctrl+C` to stop following the logs. This does not stop the containers.

### Step 5 — Test the application

Open these URLs in your browser:

- Website: http://localhost:5000
- Health endpoint: http://localhost:5000/health

Refresh the website to increment the counter. Flask sends the increment operation to Redis.

## 7. Useful commands

```bash
# Validate configuration
docker compose config

# Build and start
docker compose up -d --build

# List project containers
docker compose ps

# Follow all logs
docker compose logs -f

# Show only web logs
docker compose logs web

# Show only Redis logs
docker compose logs redis

# Open a shell in the web container
docker compose exec web sh

# Restart the web service
docker compose restart web

# Stop services without removing containers
docker compose stop

# Start stopped services
docker compose start

# Stop and remove containers and the project network
docker compose down
```

## 8. Understand persistence

Redis is configured to store data in the named volume `redis-data`.

Try this:
1. Open the website and note the counter.
2. Run `docker compose down`.
3. Run `docker compose up -d`.
4. Refresh the website. The counter should remain because the named volume is preserved.

### Important cleanup warning

```bash
docker compose down -v
```

The `-v` option also removes project-managed named volumes. This can delete the Redis data. Only use it when you intentionally want to remove the stored data.

## 9. How this Compose file works

```yaml
services:
  web:
    build: .
    ports:
      - "5000:5000"
    environment:
      REDIS_HOST: redis
    depends_on:
      redis:
        condition: service_healthy
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    command: ["redis-server", "--appendonly", "yes"]
    volumes:
      - redis-data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 3s
      retries: 5
    restart: unless-stopped

volumes:
  redis-data:
```

- `build: .`: build the web image using the Dockerfile in the current directory.
- `ports`: map host port 5000 to container port 5000.
- `environment`: pass the Redis hostname to the web service.
- `depends_on` with `service_healthy`: wait for Redis's health check to pass before starting the web service.
- `image`: choose the Redis image.
- `command`: enable Redis append-only persistence.
- `volumes`: mount a named volume at `/data`.
- `healthcheck`: checks whether Redis responds to `PING`.
- `restart`: asks Docker to restart the container under the specified conditions.

## 10. Troubleshooting

### Website does not open

```bash
docker compose ps
docker compose logs web
docker compose logs redis
```

Check that both services are running and that host port 5000 is available.

### Port 5000 is already in use

Change the host-side port mapping in `compose.yaml`:

```yaml
ports:
  - "8080:5000"
```

Then run:

```bash
docker compose up -d
```

Open http://localhost:8080.

### Redis connection fails

```bash
docker compose logs redis
docker compose exec web sh
```

Confirm the app uses the hostname `redis` and internal port `6379`. Do not use `localhost:6379` from inside the web container.

### Code changes are not visible

If code is copied into the image by the Dockerfile, rebuild the image:

```bash
docker compose up -d --build
```

## 11. Practice challenges

1. Change the host port from `5000` to `8080`.
2. Open `/health` and explain the JSON response.
3. Find the web and Redis logs separately.
4. Restart Redis and test the visit counter.
5. Run `docker compose down`, start the app again, and confirm the counter persists.
6. Explain the difference between `docker compose down` and `docker compose down -v`.
7. Identify why the Flask app connects to `redis:6379` instead of `localhost:6379`.

## 12. Production notes

This is a learning demo, not a complete production deployment. For production, review image pinning, secrets management, TLS, resource limits, monitoring, backups, network exposure, and application security. Do not commit passwords, tokens, or other secrets to a public repository.

---

# Part 2 — Telgish Explanation (Telugu + English)

## 1. Docker Compose ante enti?

**Docker Compose anedi YAML configuration file use chesi multiple Docker containers ni define cheyadaniki and run cheyadaniki use chese tool.**

Simple ga cheppalante, mana application lo web server, backend, database/cache lantivi multiple containers unte, vatini separate commands tho manage cheyyakunda `compose.yaml` file lo configuration rasukoni okesari manage cheyochu.

Mana lab lo:
- `web`: Flask website run chestundi.
- `redis`: page visits count ni store chestundi.

## 2. Main concepts

- **Service:** Compose file lo define chesina application component. Example: `web`, `redis`.
- **Container:** Image nunchi create ayye running instance.
- **Image:** Container create cheyadaniki use chese template.
- **Port mapping:** Host port ni container port ki connect chestundi. Example: `5000:5000`.
- **Network:** Services okadanitho okati communicate avvadaniki help chestundi.
- **Volume:** Container recreate ayina kuda data preserve cheyadaniki use chestham.
- **Health check:** Service correct ga respond avutunda leda ani check chestundi.

## 3. Architecture ela work avutundi?

Browser lo `http://localhost:5000` open chestham. Request Flask web container ki velthundi. Flask, visit count ni Redis lo update chestundi. Redis data `redis-data` ane named volume lo store avutundi.

Important point: web container lopala `localhost` ante web container ne. Redis ni connect cheyadaniki `redis:6379` use chestham, endukante `redis` anedi Compose service name.

## 4. Files enduku kavali?

- `compose.yaml`: services, ports, volumes, health check configuration.
- `Dockerfile`: Flask application image ela build cheyalo cheptundi.
- `requirements.txt`: Python dependencies list.
- `app.py`: website and Redis counter logic.
- `.dockerignore`: unnecessary files image build context loki vellakunda exclude chestundi.
- `README.md`: setup and practice instructions.

## 5. Docker Compose install cheyyala?

Docker Desktop lo Compose usually included untundi. Linux lo Docker Compose plugin install ayi undali.

Check cheyadaniki:

```bash
docker --version
docker compose version
```

`docker compose version` work aithe Compose available undi. `compose.yaml` file ni separate ga install cheyyalsina avasaram ledu.

## 6. Application run cheyadam

Project folder lo terminal open chesi:

```bash
docker compose config
docker compose up -d --build
docker compose ps
docker compose logs -f
```

- `config`: configuration validate chestundi.
- `up`: services create chesi start chestundi.
- `-d`: background lo run chestundi.
- `--build`: web image build chestundi.
- `ps`: containers status chupistundi.
- `logs -f`: live logs chupistundi. Logs follow cheyadam aapadaniki `Ctrl+C` press cheyochu; containers stop avvavu.

Browser lo `http://localhost:5000` open cheyyandi. Page refresh chesthe Redis counter increment avutundi.

Health endpoint: `http://localhost:5000/health`

## 7. Stop and cleanup

```bash
docker compose stop
docker compose start
docker compose down
```

`stop` containers ni stop chestundi. `start` stopped containers ni malli start chestundi. `down` containers and project network ni remove chestundi.

Careful: `docker compose down -v` use chesthe project-managed named volume remove ayi Redis data delete avvachu.

## 8. Practice tasks

1. Browser lo website open cheyyandi.
2. Page refresh chesi visit count change avvadam observe cheyyandi.
3. `docker compose ps` and `docker compose logs web` run cheyyandi.
4. `compose.yaml` lo host port `5000` ni `8080` ga change cheyyandi.
5. `docker compose down` chesi malli `docker compose up -d` run cheyyandi. Counter persist avuthundo check cheyyandi.
6. `docker compose down` ki `docker compose down -v` ki difference explain cheyyandi.

**Final takeaway:** Docker Compose lo services ni YAML file lo define chestham. Oka command tho multi-container application ni start cheyochu, logs check cheyochu, and services ni manage cheyochu.
