import os
import time

import redis
from flask import Flask, jsonify

app = Flask(__name__)
redis_host = os.getenv("REDIS_HOST", "redis")

cache = redis.Redis(
    host=redis_host,
    port=6379,
    decode_responses=True,
    socket_connect_timeout=2,
    socket_timeout=2,
)

@app.route("/")
def home():
    for attempt in range(10):
        try:
            visits = cache.incr("visits")
            return f"""
            <!doctype html>
            <html lang="en">
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Docker Compose Demo</title>
                <style>
                  body {{ font-family: Arial, sans-serif; max-width: 720px;
                         margin: 60px auto; padding: 24px; background: #f3f7fb;
                         color: #172033; }}
                  main {{ background: white; padding: 32px; border-radius: 16px;
                          box-shadow: 0 8px 30px #10204018; }}
                  h1 {{ color: #0877c9; }}
                  .count {{ font-size: 2rem; font-weight: bold; }}
                </style>
              </head>
              <body><main>
                <h1>Docker Compose Demo</h1>
                <p>Welcome to <strong>FreeCodes In Telugu</strong>!</p>
                <p>Flask web service is connected to Redis.</p>
                <p>Page visits:</p><div class="count">{visits}</div>
                <p>Refresh the page to increment the counter.</p>
                <p><a href="/health">Check application health</a></p>
              </main></body>
            </html>
            """
        except redis.RedisError:
            if attempt == 9:
                return "Redis is unavailable. Check: docker compose logs redis", 503
            time.sleep(2)

@app.route("/health")
def health():
    try:
        cache.ping()
        return jsonify(status="healthy", redis="connected")
    except redis.RedisError:
        return jsonify(status="unhealthy", redis="disconnected"), 503

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
