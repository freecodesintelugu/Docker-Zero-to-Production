# ComposeLab — Visual Docker Compose Demo

A responsive dashboard-style Flask app demonstrating a Flask web service communicating with Redis via Docker Compose.

## Run

```bash
docker compose up -d --build
docker compose ps
```

Open `http://YOUR_EC2_PUBLIC_IP:5000`. For an EC2 learning demo, restrict inbound TCP port 5000 in the security group to your own IP.

## Useful commands

```bash
docker compose logs -f
docker compose ps
docker compose restart
docker compose down
```

Redis uses a named volume and append-only persistence. The visit counter increments with each page request.
