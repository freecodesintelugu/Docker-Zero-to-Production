import os
from flask import Flask, render_template
import redis

app = Flask(__name__)
def client():
    return redis.Redis(host=os.getenv("REDIS_HOST", "redis"), port=6379, decode_responses=True, socket_connect_timeout=2)

@app.route("/")
def index():
    visits, status = None, "Unavailable"
    try:
        r = client()
        r.ping()
        visits = r.incr("page_visits")
        status = "Connected"
    except redis.RedisError:
        pass
    return render_template("index.html", visits=visits, redis_status=status)

@app.route("/health")
def health():
    try:
        client().ping()
        return {"status":"healthy","redis":"connected"}, 200
    except redis.RedisError:
        return {"status":"degraded","redis":"unavailable"}, 503

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
