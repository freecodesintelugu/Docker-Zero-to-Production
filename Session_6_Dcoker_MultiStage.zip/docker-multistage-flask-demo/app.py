from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Docker Multi-Stage Demo</title>
      <style>
        body { font-family: Arial, sans-serif; background: #f2f7fc; margin: 0; }
        main { max-width: 760px; margin: 8vh auto; padding: 32px; background: white;
               border-radius: 16px; box-shadow: 0 8px 28px #1232; }
        h1 { color: #1688d4; }
        code { background: #eef3f8; padding: 3px 7px; border-radius: 5px; }
        .ok { color: #16794b; font-weight: bold; }
      </style>
    </head>
    <body>
      <main>
        <h1>🐳 Docker Multi-Stage Build Demo</h1>
        <p class="ok">Application is running successfully!</p>
        <p>This small Flask app is packaged with a multi-stage Dockerfile.</p>
        <h2>What to learn</h2>
        <ul>
          <li><code>builder</code> stage prepares Python dependency wheels.</li>
          <li><code>runtime</code> stage installs dependencies and runs the app.</li>
          <li><code>COPY --from=builder</code> copies only selected build output.</li>
          <li>The final image does not include the builder stage's full filesystem.</li>
        </ul>
        <p>Next: build the image, run the container, then push it to Docker Hub or AWS ECR.</p>
      </main>
    </body>
    </html>
    """

@app.route("/health")
def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
