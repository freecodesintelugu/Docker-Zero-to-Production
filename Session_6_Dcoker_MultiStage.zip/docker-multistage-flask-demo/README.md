# Docker Multi-Stage Build — Flask Demo

A small Flask web application for learning Docker multi-stage builds, running a container, and pushing an image to Docker Hub or Amazon ECR.

## Project files

```text
docker-multistage-flask-demo/
├── app.py
├── requirements.txt
├── Dockerfile
├── .dockerignore
└── README.md
```

## 1. What is a multi-stage build?

A Dockerfile can contain more than one `FROM` instruction. Each `FROM` starts a new build stage.

- **Builder stage:** creates/downloads dependency wheel files in `/wheels`.
- **Runtime stage:** starts from a fresh slim Python image, installs the wheel files, and copies the application.
- **`COPY --from=builder`:** transfers selected files from the builder stage to the runtime stage.
- **Result:** the final image does not include the builder stage's entire filesystem. This example keeps the build process simple; the final size depends on the base image and installed dependencies.

## 2. Build the image

Run these commands from the project directory:

```bash
docker build -t flask-multistage-demo:v1 .
```

View the image:

```bash
docker images
```

## 3. Run the container

```bash
docker run --name flask-demo -d -p 5000:5000 flask-multistage-demo:v1
```

Open these URLs in your browser:

- App: http://localhost:5000
- Health check: http://localhost:5000/health

If Docker is running on a remote AWS Linux server, use `http://YOUR_SERVER_PUBLIC_IP:5000` only after allowing TCP port 5000 in the instance security group. For a safer production setup, put the app behind a reverse proxy or load balancer instead of exposing Flask directly.

Check logs and stop the container:

```bash
docker logs flask-demo
docker stop flask-demo
docker rm flask-demo
```

## 4. Push to Docker Hub

1. Create a repository named `flask-multistage-demo` on Docker Hub.
2. Sign in from your terminal:

```bash
docker login
```

3. Tag the local image with your Docker Hub username:

```bash
docker tag flask-multistage-demo:v1 YOUR_DOCKERHUB_USERNAME/flask-multistage-demo:v1
```

4. Push it:

```bash
docker push YOUR_DOCKERHUB_USERNAME/flask-multistage-demo:v1
```

To test the published image:

```bash
docker pull YOUR_DOCKERHUB_USERNAME/flask-multistage-demo:v1
```

## 5. Push to Amazon ECR

Prerequisites: AWS CLI installed, configured credentials (`aws configure` or an appropriate IAM role), and permission to create/use ECR repositories and push images.

Set your region and account ID. Replace the region if your ECR repository will be in another region.

```bash
export AWS_REGION=ap-south-1
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export ECR_REPO=flask-multistage-demo
export ECR_URI=$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPO
```

Create the repository (if it does not already exist):

```bash
aws ecr describe-repositories --repository-names "$ECR_REPO" --region "$AWS_REGION" >/dev/null 2>&1 || \
aws ecr create-repository --repository-name "$ECR_REPO" --region "$AWS_REGION"
```

Authenticate Docker to ECR:

```bash
aws ecr get-login-password --region "$AWS_REGION" | \
docker login --username AWS --password-stdin "$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"
```

Tag and push:

```bash
docker tag flask-multistage-demo:v1 "$ECR_URI:v1"
docker push "$ECR_URI:v1"
```

## 6. Useful troubleshooting

- **Port already in use:** change `-p 5000:5000` to `-p 8080:5000`, then browse to port 8080.
- **`docker build` cannot find Dockerfile:** run the command from this project directory.
- **Docker Hub denied:** confirm the username, repository name, and login.
- **ECR access denied:** check the active AWS identity and ECR permissions, and confirm the region matches the repository.
- **App doesn't load remotely:** check container logs and the server's firewall/security-group rules.

## Teaching summary

`builder` stage → dependency wheels → `runtime` stage → final image → run locally → push to Docker Hub or Amazon ECR.
